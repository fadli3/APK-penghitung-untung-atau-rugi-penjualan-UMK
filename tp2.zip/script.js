// ================= STORAGE =================
let produk =
  JSON.parse(localStorage.getItem('produk')) || [];

let penjualan =
  JSON.parse(localStorage.getItem('penjualan')) || [];


// ================= CHART =================
let chart;
let produkChart;


// ================= CLOCK =================
function updateClock(){

  const now = new Date();

  document.getElementById('clock').innerHTML =
    now.toLocaleString('id-ID', {
      weekday:'long',
      year:'numeric',
      month:'long',
      day:'numeric',
      hour:'2-digit',
      minute:'2-digit',
      second:'2-digit'
    });

}

setInterval(updateClock,1000);
updateClock();


// ================= COPYRIGHT =================
document.getElementById('copyright')
  .innerHTML =
  `© ${new Date().getFullYear()}
   Profit Tracker App
   | Developed by Zulfadli Adha`;


// ================= TAB =================
function openTab(tabId,button){

  document.querySelectorAll('.tab-content')
    .forEach(tab=>{
      tab.classList.remove('active');
    });

  document.querySelectorAll('.tab-btn')
    .forEach(btn=>{
      btn.classList.remove('active');
    });

  document.getElementById(tabId)
    .classList.add('active');

  button.classList.add('active');

}


// ================= FORMAT RUPIAH =================
function formatRupiah(number){

  return 'Rp ' +
    Number(number).toLocaleString('id-ID');

}


// ================= SELECT PRODUK =================
function renderSelectProduk(){

  const select =
    document.getElementById('jualNamaBarang');

  if(!select) return;

  select.innerHTML = `
    <option value="">
      Pilih Produk
    </option>
  `;

  produk.forEach((item,index)=>{

    select.innerHTML += `
      <option value="${index}">
        ${item.nama}
      </option>
    `;

  });

}


// ================= SIMPAN PRODUK =================
function simpanProduk(){

  const nama =
    document.getElementById('namaBarang').value;

  const modal =
    document.getElementById('hargaModal').value;

  const jual =
    document.getElementById('hargaJual').value;

  if(!nama || !modal || !jual){

    alert('Lengkapi data produk');

    return;

  }

  produk.push({

    nama,
    modal:Number(modal),
    jual:Number(jual)

  });

  localStorage.setItem(
    'produk',
    JSON.stringify(produk)
  );

  document.getElementById('namaBarang').value='';
  document.getElementById('hargaModal').value='';
  document.getElementById('hargaJual').value='';

  renderProduk();
  renderSelectProduk();
  renderDataProduk();
  updateDashboard();

}


// ================= RENDER PRODUK INPUT =================
function renderProduk(){

  const table =
    document.getElementById('produkInputTable');

  table.innerHTML='';

  produk.forEach((item,index)=>{

    table.innerHTML += `

      <tr>

        <td>${item.nama}</td>

        <td>
          ${formatRupiah(item.modal)}
        </td>

        <td>
          ${formatRupiah(item.jual)}
        </td>

        <td>

          <button
            class="action-btn delete-btn"
            onclick="hapusProduk(${index})">

            Hapus

          </button>

        </td>

      </tr>

    `;

  });

}


// ================= HAPUS PRODUK =================
function hapusProduk(index){

  if(confirm('Hapus produk ini?')){

    produk.splice(index,1);

    localStorage.setItem(
      'produk',
      JSON.stringify(produk)
    );

    renderProduk();
    renderSelectProduk();
    renderDataProduk();
    updateDashboard();

  }

}


// ================= SIMPAN PENJUALAN =================
function simpanPenjualan(){

  const produkIndex =
    document.getElementById('jualNamaBarang').value;

  const jumlah =
    document.getElementById('jualJumlah').value;

  const pembeli =
    document.getElementById('jualPembeli').value;

  const kontak =
    document.getElementById('jualKontak').value;

  if(
    produkIndex === '' ||
    !jumlah ||
    !pembeli ||
    !kontak
  ){

    alert('Lengkapi data penjualan');

    return;

  }

  const itemProduk =
    produk[produkIndex];

  const qty =
    Number(jumlah);

  const totalHarga =
    itemProduk.jual * qty;

  const totalModal =
    itemProduk.modal * qty;

  const labaBersih =
    totalHarga - totalModal;

  penjualan.push({

    nama:itemProduk.nama,

    jumlah:qty,

    harga:totalHarga,

    modal:totalModal,

    laba:labaBersih,

    pembeli,

    kontak,

    waktu:new Date()
      .toLocaleString('id-ID')

  });

  localStorage.setItem(
    'penjualan',
    JSON.stringify(penjualan)
  );

  document.getElementById('jualNamaBarang').value='';
  document.getElementById('jualJumlah').value='';
  document.getElementById('jualPembeli').value='';
  document.getElementById('jualKontak').value='';

  renderPenjualan();
  updateDashboard();

}


// ================= RENDER PENJUALAN =================
function renderPenjualan(){

  const table =
    document.getElementById('penjualanTable');

  table.innerHTML='';

  penjualan.forEach((item,index)=>{

    table.innerHTML += `

      <tr>

        <td>${item.nama}</td>

        <td>${item.jumlah}</td>

        <td>
          ${formatRupiah(item.harga)}
        </td>

        <td>${item.pembeli}</td>

        <td>${item.kontak}</td>

        <td>${item.waktu}</td>

        <td>

          <button
            class="action-btn delete-btn"
            onclick="hapusPenjualan(${index})">

            Hapus

          </button>

        </td>

      </tr>

    `;

  });

}


// ================= HAPUS PENJUALAN =================
function hapusPenjualan(index){

  if(confirm('Hapus data penjualan ini?')){

    penjualan.splice(index,1);

    localStorage.setItem(
      'penjualan',
      JSON.stringify(penjualan)
    );

    renderPenjualan();
    updateDashboard();

  }

}


// ================= DATA PRODUK =================
function renderDataProduk(){

  const table =
    document.getElementById('dataProdukTable');

  table.innerHTML='';

  produk.forEach(item=>{

    table.innerHTML += `

      <tr>

        <td>${item.nama}</td>

        <td>
          ${formatRupiah(item.modal)}
        </td>

        <td>
          ${formatRupiah(item.jual)}
        </td>

      </tr>

    `;

  });

}


// ================= DASHBOARD =================
function updateDashboard(){

  let omset = 0;
  let totalLaba = 0;

  penjualan.forEach(item=>{

    omset += item.harga;

    totalLaba += item.laba;

  });

  document.getElementById('omset')
    .innerText =
    formatRupiah(omset);

  document.getElementById('lababersih')
    .innerText =
    formatRupiah(totalLaba);

  document.getElementById('jumlahpenjualan')
    .innerText =
    penjualan.length;

  document.getElementById('jumlahproduk')
    .innerText =
    produk.length;

  updateChart();
  updateChartProduk();
  renderLaporanAnalitik();

}


// ================= DOWNLOAD CSV =================
function downloadCSV(){

  const filter =
    document.getElementById('filterLaporan').value;

  const now = new Date();

  let filteredData = [];

  if(filter === 'hari'){

    filteredData =
      penjualan.filter(item=>{

        const itemDate =
          new Date(item.waktu);

        return (
          itemDate.toDateString() ===
          now.toDateString()
        );

      });

  }

  else if(filter === 'bulan'){

    filteredData =
      penjualan.filter(item=>{

        const itemDate =
          new Date(item.waktu);

        return (

          itemDate.getMonth() ===
          now.getMonth()

          &&

          itemDate.getFullYear() ===
          now.getFullYear()

        );

      });

  }

  else if(filter === 'tahun'){

    filteredData =
      penjualan.filter(item=>{

        const itemDate =
          new Date(item.waktu);

        return (

          itemDate.getFullYear() ===
          now.getFullYear()

        );

      });

  }

  else{

    filteredData = penjualan;

  }

  if(filteredData.length === 0){

    alert('Tidak ada data');

    return;

  }

  let csv =
`Produk,Jumlah,Total,Pembeli,Kontak,Waktu,Laba
`;

  filteredData.forEach(item=>{

    csv +=
`${item.nama},${item.jumlah},${item.harga},${item.pembeli},${item.kontak},${item.waktu},${item.laba}
`;

  });

  const blob =
    new Blob([csv],{
      type:'text/csv'
    });

  const url =
    URL.createObjectURL(blob);

  const a =
    document.createElement('a');

  a.href = url;

  a.download =
    `laporan_${filter}.csv`;

  a.click();

}


// ================= RESET =================
function resetData(){

  if(confirm('Reset semua data?')){

    localStorage.clear();

    produk = [];
    penjualan = [];

    renderProduk();
    renderSelectProduk();
    renderPenjualan();
    renderDataProduk();
    updateDashboard();

  }

}


// ================= CHART DASHBOARD =================
function updateChart(){

  const ctx =
    document.getElementById('salesChart');

  if(!ctx || typeof Chart === 'undefined'){
    return;
  }

  const labels =
    penjualan.map(item=>item.nama);

  const data =
    penjualan.map(item=>item.harga);

  if(chart){
    chart.destroy();
  }

  chart = new Chart(ctx,{
    type:'line',

    data:{
      labels:labels,

      datasets:[{
        label:'Grafik Penjualan',
        data:data,
        borderWidth:3,
        tension:0.4
      }]
    },

    options:{
      responsive:true
    }

  });

}


// ================= CHART PRODUK =================
function updateChartProduk(){

  const filterEl =
    document.getElementById('chartFilter');

  const ctx =
    document.getElementById('produkChart');

  if(!filterEl || !ctx || typeof Chart === 'undefined'){
    return;
  }

  const filter = filterEl.value;

  let groupedData = {};

  penjualan.forEach(item=>{

    const date =
      new Date();

    let key='';

    if(filter === 'semua'){
      key = item.nama;
    }

    else if(filter === 'hari'){
      key =
        date.toLocaleDateString('id-ID');
    }

    else if(filter === 'bulan'){
      key =
        `${date.getMonth()+1}-${date.getFullYear()}`;
    }

    else if(filter === 'tahun'){
      key =
        `${date.getFullYear()}`;
    }

    if(!groupedData[key]){
      groupedData[key] = 0;
    }

    groupedData[key] += item.harga;

  });

  const labels =
    Object.keys(groupedData);

  const data =
    Object.values(groupedData);

  if(produkChart){
    produkChart.destroy();
  }

  produkChart = new Chart(ctx,{

    type:'bar',

    data:{
      labels:labels,

      datasets:[{
        label:'Total Penjualan',
        data:data,
        borderWidth:1
      }]
    },

    options:{
      responsive:true
    }

  });

}

// ================= LAPORAN ANALITIK =================
function renderLaporanAnalitik(){

  // ======================
  // PELANGGAN LOYAL
  // ======================

  const loyalTable =
    document.getElementById(
      'loyalCustomerTable'
    );

  loyalTable.innerHTML='';

  let customerData = {};

  penjualan.forEach(item=>{

    if(!customerData[item.pembeli]){

      customerData[item.pembeli] = {

        total:0,
        transaksi:0

      };

    }

    customerData[item.pembeli].total +=
      item.harga;

    customerData[item.pembeli].transaksi += 1;

  });

  Object.keys(customerData)

    .sort((a,b)=>

      customerData[b].transaksi -
      customerData[a].transaksi

    )

    .forEach(nama=>{

      loyalTable.innerHTML += `

        <tr>

          <td>${nama}</td>

          <td>
            ${formatRupiah(
              customerData[nama].total
            )}
          </td>

          <td>
            ${customerData[nama].transaksi}x
          </td>

        </tr>

      `;

    });


  // ======================
  // PRODUK TERLARIS
  // ======================

  const produkTable =
    document.getElementById(
      'produkLarisTable'
    );

  produkTable.innerHTML='';

  let produkData = {};

  penjualan.forEach(item=>{

    if(!produkData[item.nama]){

      produkData[item.nama] = 0;

    }

    produkData[item.nama] += item.jumlah;

  });

  Object.keys(produkData)

    .sort((a,b)=>

      produkData[b] -
      produkData[a]

    )

    .forEach(nama=>{

      produkTable.innerHTML += `

        <tr>

          <td>${nama}</td>

          <td>
            ${produkData[nama]} pcs
          </td>

        </tr>

      `;

    });


  // ======================
  // TOTAL STATISTIK
  // ======================

  let totalOmset = 0;
  let totalLaba = 0;

  penjualan.forEach(item=>{

    totalOmset += item.harga;

    totalLaba += item.laba;

  });

  document.getElementById('laporanOmset')
    .innerText =
    formatRupiah(totalOmset);

  document.getElementById('laporanLaba')
    .innerText =
    formatRupiah(totalLaba);

}


// ================= START =================
try{

  renderProduk();
  renderSelectProduk();
  renderPenjualan();
  renderDataProduk();
  updateDashboard();
  updateChartProduk();
  renderLaporanAnalitik();

}catch(error){

  console.log(error);

  alert(
    'Terjadi error aplikasi: ' +
    error.message
  );

}
